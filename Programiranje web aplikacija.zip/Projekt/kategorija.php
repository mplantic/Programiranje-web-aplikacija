<?php
    include 'connect.php';
?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Projekt-MarkoPlantic</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div id="tooplate_wrapper">
	<div id="tooplate_header">
        <div id="site_title"><h1><a href="#">Service Box</a></h1></div>
        
        <div id="tooplate_menu">
        <ul class="nav justify-content-center">
                    <li class="nav-item">
                    <a class="nav-link" href="index.php">HOME</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="kategorija.php?id=Sport">Sport</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="kategorija.php?id=CrnaKronika">CrnaKronika</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="administracija.php">ADMINISTRACIJA</a>
                    </li>
                </ul>	
        </div> 
    
	</div> 
    <div id="tooplate_main">
    <section>
            <div class="col_w420">
            <?php
                        $kategorija=$_GET['id'];
                        $query= "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='$kategorija'";
                        $result=mysqli_query($dbc,$query);
                        while($row=mysqli_fetch_array($result)){
                            echo "<div class='col-4'>";          
                            echo "<a href='clanak.php?id=" . $row['id'] . "'/>";
                            echo "<img src='img/" . $row['slika'] . "'>";
                            echo "<h2>" . $row['naslov'] . "</h2>";
                            echo $row['datum'];
                            echo "</a>";
                            echo "</div>";
                        };
                        mysqli_close($dbc);
                    ?>
            </div>
        </section>
    </div>
</div>
</body>
</html>