﻿<?php
    include 'connect.php';
    define('UPLPATH', 'img/');
?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Projekt-MarkoPlantic</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div id="tooplate_wrapper">
	<div id="tooplate_header">
        <div id="site_title"><h1><a href="#">Projekt</a></h1></div>
        
        <div id="tooplate_menu">
        <ul class="nav justify-content-center">
                    <li class="nav-item">
                    <a class="nav-link" href="index.php">HOME</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="kategorija.php?id=Sport">Sport</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="kategorija.php?id=CrnaKronika">CrnaKronika</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="administracija.php">ADMINISTRACIJA</a>
                    </li>
                </ul>	
        </div> 
    
	</div> 
    
    <div id="tooplate_main">
        
        <div id="tooplate_content">

            <div class="ol_allw280 lp_box col_first">
            <h2>Sport</h2>

            <?php
                        $query="SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='Sport' LIMIT 3";
                        $result=mysqli_query($dbc,$query);
                        while($row=mysqli_fetch_array($result)){
                            echo "<div class='col_allw280'>";
                            echo "<a href='clanak.php?id=" . $row['id'] . "'>";
                            echo "<img src='images/" . $row['slika'] . "'>";
                            echo "<h2>" . $row['naslov'] . "</h2>";
                            echo $row['datum'];
                            echo "</a>";
                            echo "</div>";
                            }
                    ?>
				
				<div class="col_allw280 ">
                <?php
                        $query="SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='Sport' LIMIT 3";
                        $result=mysqli_query($dbc,$query);
                        while($row=mysqli_fetch_array($result)){
                            echo "<div class='col_allw280'>";
                            echo "<a href='clanak.php?id=" . $row['id'] . "'>";
                            echo "<img src='images/" . $row['slika'] . "'>";
                            echo "<h2>" . $row['naslov'] . "</h2>";
                            echo $row['datum'];
                            echo "</a>";
                            echo "</div>";
                            }
                    ?>
                </div>
                
				<div class="col_allw280 lp_box col_last">
                <?php
                        $query="SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='Sport' LIMIT 3";
                        $result=mysqli_query($dbc,$query);
                        while($row=mysqli_fetch_array($result)){
                            echo "<div class='col_allw280'>";
                            echo "<a href='clanak.php?id=" . $row['id'] . "'>";
                            echo "<img src='images/" . $row['slika'] . "'>";
                            echo "<h2>" . $row['naslov'] . "</h2>";
                            echo $row['datum'];
                            echo "</a>";
                            echo "</div>";
                            }
                    ?>
                </div>
                
				<div class="cleaner h60"></div>
			
                
                <div class="cleaner"></div>
            
			</div>
            
            <div class="col_w900 col_w900_last">

            	<div class="con_tit_02">Crna Kronika</div>
                
				<?php
                        $query="SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='CrnaKronika' LIMIT 3";
                        $result=mysqli_query($dbc,$query);
                        while($row=mysqli_fetch_array($result)){
                            echo "<div class='col_allw280 lp_box'>";
                            echo "<a href='clanak.php?id=" . $row['id'] . "'>";
                            echo "<img src='images/" . $row['slika'] . "'>";
                            echo "<h2>" . $row['naslov'] . "</h2>";
                            echo $row['datum'];
                            echo "</a>";
                            echo "</div>";
                            }
                    ?>
                
				<div class="col_allw280 lp_box">
                <?php
                        $query="SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='CrnaKronika' LIMIT 3";
                        $result=mysqli_query($dbc,$query);
                        while($row=mysqli_fetch_array($result)){
                            echo "<div class='col_allw280 lp_box'>";
                            echo "<a href='clanak.php?id=" . $row['id'] . "'>";
                            echo "<img src='images/" . $row['slika'] . "'>";
                            echo "<h2>" . $row['naslov'] . "</h2>";
                            echo $row['datum'];
                            echo "</a>";
                            echo "</div>";
                            }
                    ?>
            	</div>
				
				<div class="col_allw280 lp_box col_last">
                <?php
                        $query="SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='CrnaKronika' LIMIT 3";
                        $result=mysqli_query($dbc,$query);
                        while($row=mysqli_fetch_array($result)){
                            echo "<div class='col_allw280 col_last'>";
                            echo "<a href='clanak.php?id=" . $row['id'] . "'>";
                            echo "<img src='images/" . $row['slika'] . "'>";
                            echo "<h2>" . $row['naslov'] . "</h2>";
                            echo $row['datum'];
                            echo "</a>";
                            echo "</div>";
                            }
                    ?>
                </div>
                
				<div class="cleaner"></div>
            </div>
            
        </div> 
        
    </div>
    
    <div id="tooplate_footer">
    	Marko Plantić 2022. <a href="#">mplantic@tvz.hr</a>
	</div> 
    
</div> 
</body>
</html>