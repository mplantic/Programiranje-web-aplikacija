-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2022 at 01:26 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vijesti`
--

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `id` int(11) NOT NULL,
  `ime` varchar(32) NOT NULL,
  `prezime` varchar(32) NOT NULL,
  `korisnicko_ime` varchar(32) NOT NULL,
  `lozinka` varchar(255) NOT NULL,
  `razina` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id`, `ime`, `prezime`, `korisnicko_ime`, `lozinka`, `razina`) VALUES
(1, 'Marko', 'Plantic', 'mplantic', '12345', 1),
(2, 'Marko', 'Plantic', 'marko.plantic', '$2y$10$PAIah/H5K7P/sif2eerIK.aJUFYOjm8S9v60EbjnmvbdOJuGq.Pl.', 0);

-- --------------------------------------------------------

--
-- Table structure for table `vijesti`
--

CREATE TABLE `vijesti` (
  `id` int(11) NOT NULL,
  `datum` date NOT NULL,
  `naslov` varchar(64) NOT NULL,
  `sazetak` text NOT NULL,
  `tekst` text NOT NULL,
  `slika` varchar(64) NOT NULL,
  `kategorija` varchar(64) NOT NULL,
  `arhiva` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vijesti`
--

INSERT INTO `vijesti` (`id`, `datum`, `naslov`, `sazetak`, `tekst`, `slika`, `kategorija`, `arhiva`) VALUES
(8, '0000-00-00', 'Dinamo dogovara drugu najveću kupovinu u povijesti kluba? Dovodi', 'HRVATSKI 21-godišnji branič Boško Šutalo uskoro bi se mogao vratiti u HNL. Nogometaš koji je ranije igrao u Osijeku pa iz njega za 5.5 milijuna Eura otišao u Atalantu, želja je Dinama, piše SportItalia koji tvrdi da su pregovori u već poodmakloj fazi.\r\n', 'Šutalo s Atalantom ima ugovor do ljeta 2024., a u Bergamo je stigao u siječnju 2020. iz Osijeka. Za Atalantu je u Serie A skupio ukupno 14 nastupa u jednoj i pol sezoni, a nastupio je u dvije utakmice talijanskog kupa, u kojima je postigao svoj jedini pogodak za momčad iz Bergama.\r\n\r\nDinamo je spreman platiti ogroman iznos?\r\nNakon toga je otišao na posudbu u Hellas Veronu koju je prvo trenirao Ivan Jurić, a onda i Igor Tudor te tamo imao redovitu minutažu kad god ne bi imao problema s ozljedama, ali se nikad nije uspio do kraja nametnuti. I dalje je igrač Atalante, a Dinamo bi to htio promijeniti već ovog ljeta.\r\n\r\nŠutalo može pokriti poziciju desnog beka, onu na kojoj Dinamo nema jasno prvo rješenje. Na toj poziciji u Dinamu igraju Stefan Ristovski i Sadegh Moharrami, ali nitko od njih nije se nametnuo kao jasan prvotimac.\r\n\r\nSamo Rog bi bio skuplji\r\nVeliki adut Šutala je što je osim pozicije desnog beka sposoban pokriti i poziciju desnog stopera, posebno ako se radi o toj poziciji u sustavu s tri igrača u zadnjoj liniji, za kojeg se spekulira da bi ga Čačić mogao koristiti sljedeće sezone.\r\n\r\nKada bi do ovog transfera došlo, Šutalo bi postao drugim najskupljim ulaznim transferom u povijesti Dinama, ispred njega bi ostao samo Marko Rog koji je, prema Transfermarktu, u Dinamo stigao za 4.5 milijuna eura iz Splita.\r\n\r\n', 'slika.jpg', 'Sport', 0),
(9, '0000-00-00', 'Kod Splićanina pronađene dvije kile speeda', 'POLICIJSKI službenici Službe kriminaliteta droga Policijske uprave splitsko-dalmatinske dovršili su kriminalističko istraživanje nad 38-godišnjim muškarcem, hrvatskim državljaninom.\r\n\r\n', 'Policijski službenici jučer su kod njega pronašli i oduzeli 8 vrećica u kojima se ukupno nalazilo 2090 grama droge amfetamin - \"speed\", objavljeno je na stranicama PU splitsko-dalmatinske. Uhićen je, doveden u službene prostorije i nad njim je provedeno kriminalističko istraživanje.\r\n\r\nNakon provedenog istraživanja 38-godišnji muškarac priveden je pritvorskom nadzorniku zbog postojanja osnovane sumnje u počinjenje kaznenog djela neovlaštene proizvodnje i prometa drogama.\r\n\r\n', 'slika2.jpg', '', 0),
(10, '0000-00-00', 'Kod Splićanina pronađene dvije kile speeda', 'POLICIJSKI službenici Službe kriminaliteta droga Policijske uprave splitsko-dalmatinske dovršili su kriminalističko istraživanje nad 38-godišnjim muškarcem, hrvatskim državljaninom.\r\n\r\n', 'Policijski službenici jučer su kod njega pronašli i oduzeli 8 vrećica u kojima se ukupno nalazilo 2090 grama droge amfetamin - \"speed\", objavljeno je na stranicama PU splitsko-dalmatinske. Uhićen je, doveden u službene prostorije i nad njim je provedeno kriminalističko istraživanje.\r\n\r\nNakon provedenog istraživanja 38-godišnji muškarac priveden je pritvorskom nadzorniku zbog postojanja osnovane sumnje u počinjenje kaznenog djela neovlaštene proizvodnje i prometa drogama.\r\n\r\n', 'slika2.jpg', 'CrnaKronika', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `korisnicko_ime` (`korisnicko_ime`);

--
-- Indexes for table `vijesti`
--
ALTER TABLE `vijesti`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vijesti`
--
ALTER TABLE `vijesti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
