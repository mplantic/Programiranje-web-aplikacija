
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Projekt-MarkoPlantic</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>


<body>

<?php
    $picture = $_FILES['pphoto']['name'];
    $title=$_POST['title'];
    $about=$_POST['about'];
    $content=$_POST['content'];
    $category=$_POST['category'];
    $date=$_POST['datum'];
    $date=date('d.m.Y.',strtotime($date));
    if(isset($_POST['archive'])){
        $archive=1;
    }else{
        $archive=0;
    }
    $target_dir = 'images/'.$picture;
    move_uploaded_file($_FILES["pphoto"]["tmp_name"], $target_dir);

    $dbc = mysqli_connect('localhost', 'root', '', 'Vijesti') or 
    die('Error connecting to MySQL server.'. mysqli_connect_error());
    

    $query = "INSERT INTO vijesti (datum, naslov, sazetak, tekst, slika, kategorija, 
    arhiva ) VALUES ('$date', '$title', '$about', '$content', '$picture', 
    '$category', '$archive')";

    $result = mysqli_query($dbc, $query) or die('Error querying databese.'); 
    mysqli_close($dbc);
    
?>
 </p>
 </section>
 </section>
</body>
</html>