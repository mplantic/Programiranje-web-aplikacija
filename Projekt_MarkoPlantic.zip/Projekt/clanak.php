<?php
    include 'connect.php';
?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Projekt-MarkoPlantic</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
</body>
<div id="tooplate_wrapper">
<div id="tooplate_header">
        <div id="site_title"><h1><a href="#">Service Box</a></h1></div>
        
        <div id="tooplate_menu">
        <ul class="nav justify-content-center">
                    <li class="nav-item">
                    <a class="nav-link" href="index.php">HOME</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="kategorija.php?id=Sport">Sport</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="kategorija.php?id=CrnaKronika">CrnaKronika</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="administracija.php">ADMINISTRACIJA</a>
                    </li>
                </ul>	
        </div> 
    
	</div> 
    <div id="tooplate_main">
    <section>
            <div class="col_w420">
                <?php
                    $id=$_GET['id'];
                    $query="SELECT * FROM vijesti WHERE id='$id'";
                    $result=mysqli_query($dbc,$query);
                    while($row=mysqli_fetch_array($result)){
                        echo "<img src='images/" . $row['slika'] . "'>";
                        echo "<h1>" . $row['naslov'] . "</h1>";
                        echo "<p>" . $row['datum'] . "</p>";
                        echo "<p>" . $row['tekst'] . "</p>";
                        }
                ?>
            </div>
        </section>
    </div>
</div>
<div id="tooplate_footer">
    	Marko Plantić 2022. <a href="#">mplantic@tvz.hr</a>
	</div>
</html>